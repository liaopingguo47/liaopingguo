CREATE TABLE `plans` (
	`date` text PRIMARY KEY NOT NULL,
	`play` text NOT NULL,
	`food` text NOT NULL,
	`note` text NOT NULL,
	`updated` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rewards` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`date` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`joined` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `wishes` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`email` text NOT NULL,
	`wish` text NOT NULL,
	`address` text NOT NULL,
	`created` text NOT NULL,
	`status` text NOT NULL
);
