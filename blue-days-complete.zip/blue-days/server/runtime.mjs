import {AsyncLocalStorage} from 'node:async_hooks';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdirSync,existsSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
export const context=new AsyncLocalStorage();
export const dataDir=resolve(process.env.DATA_DIR||'data');mkdirSync(dataDir,{recursive:true});
const configPath=resolve(dataDir,'runtime-config.json');
if(!existsSync(configPath)){writeFileSync(configPath,JSON.stringify({ADMIN_KEY:randomBytes(18).toString('base64url'),COOKIE_SECRET:randomBytes(32).toString('hex')},null,2),{mode:0o600,flag:'wx'});console.log('首次启动：管理口令已生成。查看 '+configPath+' 中的 ADMIN_KEY。');}
const config=JSON.parse(readFileSync(configPath,'utf8'));
export const cookieSecret=process.env.COOKIE_SECRET||config.COOKIE_SECRET;
const sqlite=new DatabaseSync(resolve(dataDir,'blue-days.sqlite'));
sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
if(!sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get())sqlite.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
sqlite.exec('CREATE INDEX IF NOT EXISTS idx_rewards_user ON rewards(user); CREATE INDEX IF NOT EXISTS idx_wishes_user ON wishes(user);');
class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}first(){return sqlite.prepare(this.sql).get(...this.args)||null;}all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}run(){const r=sqlite.prepare(this.sql).run(...this.args);return {meta:{changes:r.changes}};}}
export const env={ADMIN_KEY:process.env.ADMIN_KEY||config.ADMIN_KEY,DB:{prepare:sql=>new Statement(sql),batch:async statements=>{sqlite.exec('BEGIN IMMEDIATE');try{const results=statements.map(s=>s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}}};
export async function invited(){return !!context.getStore()?.user;}
export async function getVisitor(){return context.getStore()?.user||null;}
export function closeDb(){sqlite.close();}
