import {createServer} from 'node:http';
import {createHmac,randomUUID,timingSafeEqual} from 'node:crypto';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {context,cookieSecret,closeDb} from './runtime.mjs';
import {GET,POST} from './data.mjs';
const dist=resolve('dist');
const sign=x=>createHmac('sha256',cookieSecret).update(x).digest('base64url');
function valid(token){if(!token)return null;const [id,sig]=token.split('.');if(!/^guest_[0-9a-f-]{36}$/.test(id)||!sig||! /^[A-Za-z0-9_-]{43}$/.test(sig))return null;const expected=sign(id);return sig.length===expected.length&&timingSafeEqual(Buffer.from(sig),Buffer.from(expected))?id:null;}
function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').map(v=>{const i=v.indexOf('=');return [v.slice(0,i).trim(),v.slice(i+1).trim()];}));}
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.json':'application/json'};
let weatherCache=null;
async function weather(){if(weatherCache&&Date.now()-weatherCache.at<1800000)return Response.json(weatherCache.data);try{const r=await fetch('https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia%2FShanghai&forecast_days=16',{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('weather '+r.status);const d=await r.json();if(!d.daily?.time)throw Error('invalid weather response');weatherCache={at:Date.now(),data:d.daily};return Response.json(d.daily);}catch{return Response.json({unavailable:true},{status:503});}}
const rate=new Map();
function allowed(key,max){const now=Date.now();let entry=rate.get(key);if(!entry||now>entry.until){entry={n:0,until:now+60000};rate.set(key,entry);}if(rate.size>10000)for(const [k,v]of rate)if(v.until<now)rate.delete(k);return ++entry.n<=max;}
const server=createServer(async(req,res)=>{try{const headers=new Headers(req.headers);const forwarded=process.env.TRUST_PROXY==='1';const proto=forwarded&&req.headers['x-forwarded-proto']==='https'?'https':'http';const origin=process.env.PUBLIC_ORIGIN||`${proto}://${req.headers.host}`;const url=new URL(req.url,origin);res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Cache-Control','no-store');if(url.pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json'});return res.end('{"ok":true}');}
let id=valid(cookies(req).blue_session);if(!id){id='guest_'+randomUUID();res.setHeader('Set-Cookie',`blue_session=${id}.${sign(id)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${origin.startsWith('https:')?'; Secure':''}`);}
const user={userId:id,email:'访客 '+id.slice(-6)};
if(url.pathname==='/api/data'||url.pathname==='/api/weather'){if(!['GET','POST'].includes(req.method)){res.writeHead(405);return res.end();}if(!allowed(id+':api',180)){res.writeHead(429);return res.end('{"error":"操作太快，请稍后重试"}');}if(headers.get('x-admin-key')&&!allowed(req.socket.remoteAddress+':admin',20)){res.writeHead(429);return res.end('{"error":"管理请求过多，请稍后重试"}');}let body;if(req.method==='POST'){const chunks=[];let size=0;for await(const c of req){size+=c.length;if(size>65536){res.writeHead(413);return res.end();}chunks.push(c);}body=Buffer.concat(chunks);}
const request=new Request(new URL(url.pathname+url.search,origin),{method:req.method,headers,...(body?{body}: {})});const response=await context.run({user},()=>url.pathname==='/api/weather'?weather():req.method==='POST'?POST(request):GET(request));for(const [k,v]of response.headers)res.setHeader(k,v);res.writeHead(response.status);return res.end(Buffer.from(await response.arrayBuffer()));}
if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
let pathname;try{pathname=decodeURIComponent(url.pathname);}catch{res.writeHead(400);return res.end();}let file=resolve(dist,'.'+pathname);if(!file.startsWith(dist+'/')&&file!==dist){res.writeHead(403);return res.end();}if(pathname==='/'||pathname==='/join')file=resolve(dist,'index.html');try{if(!(await stat(file)).isFile())throw Error('not file');}catch{res.writeHead(404);return res.end('Not found');}const bytes=await readFile(file);res.setHeader('Content-Type',types[extname(file)]||'application/octet-stream');if(pathname.startsWith('/assets/'))res.setHeader('Cache-Control','public,max-age=31536000,immutable');res.writeHead(200);res.end(req.method==='HEAD'?undefined:bytes);
}catch(e){console.error(e);if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});res.end('{"error":"服务暂时不可用，请稍后重试"}');}});
server.listen(Number(process.env.PORT||3000),process.env.HOST||'0.0.0.0',()=>console.log('一起出门已启动，端口 '+(process.env.PORT||3000)));
function shutdown(){server.close(()=>{closeDb();process.exit(0);});setTimeout(()=>process.exit(1),5000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
