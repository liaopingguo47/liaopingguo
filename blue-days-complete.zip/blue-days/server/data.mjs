import { env, invited, getVisitor } from './runtime.mjs';
export const dynamic = 'force-dynamic';
const today = () => new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Shanghai' }).format(new Date());
function db() { if (!env.DB)
    throw Error('数据暂时无法连接，请稍后重试'); return env.DB; }
const json = (x, status = 200) => Response.json(x, { status, headers: { 'Cache-Control': 'no-store' } });
async function points(user) { const u = await db().prepare('SELECT joined FROM users WHERE id=?').bind(user).first(); const r = await db().prepare('SELECT COUNT(*) AS n FROM rewards WHERE user=?').bind(user).first(); const w = await db().prepare('SELECT COUNT(*) AS n FROM wishes WHERE user=?').bind(user).first(); return Math.max(0, Math.floor((Date.parse(today()) - Date.parse(u.joined)) / 86400000) + 1) + r.n - w.n; }
export async function GET(req) { try {
    if (!await invited())
        return json({ error: '请从邀请链接进入' }, 403);
    const user = await getVisitor();
    if (!user)
        return json({ error: '请重新打开邀请链接' }, 401);
    await db().prepare('INSERT OR IGNORE INTO users (id,email,joined) VALUES (?,?,?)').bind(user.userId, user.email, today()).run();
    const admin = req.headers.get('x-admin-key');
    if (admin) {
        if (admin !== env.ADMIN_KEY)
            return json({ error: '管理口令不正确' }, 403);
        return json({ wishes: (await db().prepare('SELECT * FROM wishes ORDER BY created DESC').all()).results });
    }
    return json({ today: today(), points: await points(user.userId), plans: (await db().prepare('SELECT * FROM plans ORDER BY date').all()).results, wishes: (await db().prepare('SELECT * FROM wishes WHERE user=? ORDER BY created DESC').bind(user.userId).all()).results });
}
catch (e) {
    console.error(e);
    return json({ error: '暂时无法读取，请稍后重试' }, 503);
} }
export async function POST(req) { try {
    if (!await invited())
        return json({ error: '请从邀请链接进入' }, 403);
    const user = await getVisitor();
    if (!user)
        return json({ error: '请重新打开邀请链接' }, 401);
    if (req.headers.get('origin') !== new URL(req.url).origin)
        return json({ error: '请求无效' }, 403);
    const b = await req.json();
    await db().prepare('INSERT OR IGNORE INTO users (id,email,joined) VALUES (?,?,?)').bind(user.userId, user.email, today()).run();
    if (b.action === 'plan') {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(b.date) || !Number.isFinite(Date.parse(b.date)) || new Date(b.date).toISOString().slice(0, 10) !== b.date || b.date < today())
            return json({ error: '请选择今天或之后的日期' }, 400);
        if (!Array.isArray(b.play) || !Array.isArray(b.food) || b.play.length + b.food.length === 0)
            return json({ error: '至少选一个想玩或想吃的项目' }, 400);
        const valid = (a) => a.length <= 150 && a.every(x => typeof x === 'string' && x.trim() && x.length <= 100);
        if (!valid(b.play) || !valid(b.food) || typeof b.note !== 'string' || b.note.length > 1000)
            return json({ error: '内容过长或格式不正确' }, 400);
        await db().batch([db().prepare('INSERT INTO plans (date,play,food,note,updated) VALUES (?,?,?,?,?) ON CONFLICT(date) DO UPDATE SET play=excluded.play,food=excluded.food,note=excluded.note,updated=excluded.updated').bind(b.date, JSON.stringify([...new Set(b.play)]), JSON.stringify([...new Set(b.food)]), b.note, new Date().toISOString()), db().prepare('INSERT OR IGNORE INTO rewards (id,user,date) VALUES (?,?,?)').bind(user.userId + ':' + b.date, user.userId, b.date)]);
        return json({ ok: true });
    }
    if (b.action === 'wish') {
        if (typeof b.wish !== 'string' || !b.wish.trim() || b.wish.length > 500 || typeof b.address !== 'string' || !b.address.trim() || b.address.length > 1000 || !/^[-\w]{10,80}$/.test(b.id))
            return json({ error: '请填写小心愿和地址' }, 400);
        const result = await db().prepare("INSERT OR IGNORE INTO wishes (id,user,email,wish,address,created,status) SELECT ?,?,?,?,?,?,'待实现' FROM users u WHERE u.id=? AND (CAST(julianday(?) - julianday(u.joined) AS INTEGER)+1+(SELECT COUNT(*) FROM rewards WHERE user=u.id)-(SELECT COUNT(*) FROM wishes WHERE user=u.id))>=1").bind(b.id, user.userId, user.email, b.wish.trim(), b.address.trim(), new Date().toISOString(), user.userId, today()).run();
        if (!result.meta.changes) {
            const old = await db().prepare('SELECT id FROM wishes WHERE id=? AND user=?').bind(b.id, user.userId).first();
            if (!old)
                return json({ error: '积分不足，明天再来看看' }, 400);
        }
        return json({ ok: true });
    }
    if (b.action === 'status') {
        if (req.headers.get('x-admin-key') !== env.ADMIN_KEY)
            return json({ error: '管理口令不正确' }, 403);
        if (!['待实现', '已完成'].includes(b.status))
            return json({ error: '状态无效' }, 400);
        await db().prepare('UPDATE wishes SET status=? WHERE id=?').bind(b.status, b.id).run();
        return json({ ok: true });
    }
    return json({ error: '操作无效' }, 400);
}
catch (e) {
    console.error(e);
    return json({ error: '保存失败，输入已保留，请重试' }, 503);
} }
