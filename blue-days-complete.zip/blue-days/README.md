# 一起出门 · 完整部署包

本包包含完整前端源码、预构建网页、独立 Node.js 后台、SQLite 数据库建表脚本、Docker 配置和中文部署说明。无需登录 ChatGPT，不调用 chatgpt.site，不依赖原 Sites 数据库。

## 先看这里

- 运行环境：**Node.js 24 或 Docker**，以及可写、持久化的磁盘。
- 已包含 `dist/` 和 `server/data.mjs`，**直接运行无需 npm install、无需重新构建、无需填写数据库账号**。
- 可把所有文件上传到 GitHub 仓库，再让支持 Node/Docker 的托管平台从仓库部署。
- **GitHub Pages 不能运行后台。仅把文件上传到仓库或启用 Pages，不会获得完整可运行的网站。** `dist` 也不是能单独运行完整功能的部署包。
- 服务器必须保持运行。请使用单进程、单实例；不要将 SQLite 数据目录放在临时文件系统或多实例间共享。
- 用户访问的网址由你选择的服务器/托管平台分配。此文件包不包含新网址，也不能保证特定托管域名在中国内地的可达性，需上线后用目标网络验证。

## 最快启动：有 Node.js 24 的电脑或服务器

1. 解压，进入包含 `package.json` 的 `blue-days` 文件夹。
2. 运行：

```sh
node server/index.mjs
```

3. 同机浏览器打开 `http://localhost:3000`。Windows 也可双击 `start.bat`；macOS/Linux 可执行 `sh start.sh`。

首次启动会自动创建 `data/blue-days.sqlite` 和 `data/runtime-config.json`。在 `runtime-config.json` 中找到 `ADMIN_KEY`，输入网页底部“管理”入口，即可查看所有兑换内容、地址和处理状态。该文件请保密，不要上传 GitHub。旧网站的管理口令不适用于这个独立部署版。

`localhost` 仅供本机调试。让其他手机访问，需要把服务部署到外网服务器并放行对应端口，正式使用通过 HTTPS 访问；不要把 `localhost` 地址发给对方。

## Docker 部署：推荐用于服务器

在本文件夹中执行：

```sh
docker compose up -d --build
```

访问服务器的 3000 端口。镜像使用 Node.js 24，复制预构建文件，不在镜像里安装 npm 包。首次拉取基础镜像需要服务器能访问 Docker 镜像源；若拉取失败，需要配置该服务器可用的镜像源。

管理口令读取命令：

```sh
docker compose exec app node -e "console.log(JSON.parse(require('node:fs').readFileSync('/app/data/runtime-config.json','utf8')).ADMIN_KEY)"
```

数据保存在 Docker 命名卷 `blue_days_data` 中，容器重建后仍保留。**不要执行 `docker compose down -v`，它会删除数据卷。**

如果使用云托管平台而不是 Compose：选择根目录的 Dockerfile，容器端口 `3000`，并把持久化磁盘挂载到 `/app/data`。只允许一个实例。没有持久化磁盘的平台重部署可能丢失数据，不适合直接运行本版本。

## GitHub 上传与部署

1. 新建仓库，把解压后 `blue-days/` 中的全部文件和文件夹上传到仓库根目录，包括 `dist`、`server`、`Dockerfile`、`compose.yaml` 和 `package.json`。
2. 不要只上传 ZIP；托管平台需要看到解压后的 Dockerfile/源码。不要上传自己运行后生成的 `data`、`.env`、数据库文件或 `node_modules`。
3. 在你的服务器下载仓库，按上面的 Docker 或 Node 命令启动；或在支持 Docker 和持久化磁盘的托管平台关联这个仓库。
4. 平台若要求 Node 启动命令，填 `node server/index.mjs`；不需要构建步骤。选择 Node 24。工作目录为仓库根目录。
5. 通过托管平台分配的网址访问，再配置 HTTPS 和下面的公开网址变量。

这里只提供源码与可运行包，不会替你创建云服务、支付费用或执行发布。GitHub 官方 Pages 说明：https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages

## HTTPS 与反向代理

默认是同源前后端，不需要配置 CORS。页面和 `/api/data`、`/api/weather` 必须通过同一个域名访问。建议放在域名根目录，不要挂载在子目录。

如果外层使用 Nginx、Caddy、云托管 HTTPS 入口或其他反向代理：

- 设置 `PUBLIC_ORIGIN=https://你的实际域名`，不带末尾 `/`。
- 代理转发所有请求至应用端口 3000。
- 确保 Node 只能通过可信代理访问时，才可以设置 `TRUST_PROXY=1`。直接设置正确的 `PUBLIC_ORIGIN` 即可，不必依赖转发头。
- HTTPS 时会使用 Secure Cookie。第一次正式使用前配置好公开域名；从 HTTP/IP 切换到 HTTPS/域名后，浏览器会把它识别为新的访问者。

服务器端环境变量不应写进前端代码或提交到公共仓库。可以复制 `.env.example` 为 `.env` 并自行修改。Docker Compose 自动读取 `.env`；直接 Node 可运行：

```sh
node --env-file=.env server/index.mjs
```

## 环境变量

| 变量 | 默认 | 用途 |
| --- | --- | --- |
| `PORT` | `3000` | Node 监听端口；Compose 中是宿主机映射端口 |
| `HOST` | `0.0.0.0` | Node 监听地址 |
| `DATA_DIR` | `./data` | 数据库和密钥文件的持久化目录；Docker 中为 `/app/data` |
| `ADMIN_KEY` | 首次启动自动生成并保存 | 管理口令，可在服务端改成自己的强口令 |
| `COOKIE_SECRET` | 首次启动自动生成并保存 | 浏览器身份签名密钥，必须长期保持不变 |
| `PUBLIC_ORIGIN` | 根据请求地址生成 | 对外访问的完整来源地址，例如 `https://example.com`，反向代理部署时建议显式填写 |
| `TRUST_PROXY` | `0` | 是否信任反向代理的 HTTPS 转发标记 |

不配置 `ADMIN_KEY` 和 `COOKIE_SECRET` 也能直接启动，系统会生成随机值；不是空口令。没有通用、写死在源码中的管理口令。

## 保留的功能

- 浅蓝色移动端竖屏日历，默认当前月份、北京时间，支持滑动换月、星期显示、过去日期变灰。
- 每周重复课表：周二/周三实习，周四/周五课程和周四晚家教，周六家教；不包含周日家教。
- 点击日期查看固定安排与可用时间；从原 Excel 导入 70 项“玩”、31 项“吃”；多选、自定义添加、备注、保存和后续修改。
- 所有访问者共享这个日历。网址只发给你希望共同使用的人；此版不设置账号登录或日历成员权限。
- 每个浏览器首次访问当天得到 1 分，此后按北京时间自然日累计；即使没有每天打开，也会在下次打开时计算累计分数。
- 每个浏览器对每个日期首次保存行程额外奖励 1 分，反复修改同日行程不重复奖励。
- 1 积分兑换 1 个心愿，填写心愿与地址；后台校验余额，重试同一个兑换请求不会重复扣分。
- 普通访问者只能看到当前浏览器的心愿；管理口令可查看全部心愿、地址、匿名访客编号、提交时间，并标记已完成。
- 无需登录。浏览器 Cookie 识别访问者，数据库保存实际数据。清除 Cookie、换浏览器或换域名会产生新身份；没有跨设备账号同步或防刷积分账户体系。

### 北京天气

服务端实时请求 Open-Meteo 北京未来最多16天预报，并短暂缓存。只展示接口实际返回的日期，不伪造远期天气。天气接口无法访问时该区域隐藏，行程和兑换仍可用。天气服务仍依赖服务器到 `api.open-meteo.com` 的网络，并不保证所有中国内地服务器都可连接。天气来源与署名保留在日期页。

## 数据、备份和迁移

- 数据库初次启动自动建表，SQL 在 `server/schema.sql`。
- 这是可重新部署的完整代码包，**不包含旧 chatgpt.site 上的用户数据、地址、访问凭证或任何私密密钥**；旧服务数据不会自动迁移。
- 备份时先停止服务，再备份整个数据目录（包括数据库及 runtime-config.json），随后重启。Docker 可先 `docker compose stop app`，复制卷内 `/app/data`，再 `docker compose start app`。
- 恢复时在停止状态下恢复整个数据目录，保留密钥和文件权限，再启动。不要只复制运行中的主 sqlite 文件，WAL 中可能还有数据。
- 数据目录必须可写。更新代码时保留数据目录/数据卷。此包不支持无持久化磁盘的多实例 Serverless 部署。

## 修改源码

日常部署不需要这一步。只有修改页面或 `server/data.ts` 后才需要重新构建：

```sh
npm install
npm run build
npm test
```

源码入口：`src/Planner.tsx`；样式：`src/style.css`；原始选项：`src/catalog.json`。构建同时更新 `dist/` 和 `server/data.mjs`。后端 Node 运行时只使用内置模块；`package.json` 内的依赖只用于修改与构建。

## 检查与排错

- 健康检查：`GET /health` 应返回 `{"ok":true}`。
- 自动流程检查：`npm test`，用临时数据库测试实际 HTTP 接口和重启持久化，不改你的正式数据。
- 白屏：确认上传了整个 `dist`，特别是 `dist/assets`，并在网站根路径运行。
- 不能保存、提示“请求无效”：检查 `PUBLIC_ORIGIN` 是否与地址栏完全一致（协议、域名、端口）。
- 启动报 `node:sqlite` 不存在：运行环境太旧，使用 Node.js 24。
- 重启积分/身份丢失：确认 Cookie 没被清理，访问域名未变，数据目录和签名密钥仍保留。
- 入口文件 `index.html` 是构建源码，正式服务应通过 Node/Docker 访问 `dist/index.html`；不要直接双击 HTML 期待后台工作。
- `chatgpt.site` 的旧链接不属于这份独立部署；不再需要它。

## 本包验证结果

已在 Node.js 24.19.0 下构建，并通过实际 HTTP 流程测试：静态资源、双浏览器共享行程、修改保存、自定义标签、每日积分、重复奖励/兑换保护、余额不足/并发兑换、管理口令校验、心愿隔离、处理状态、来源校验、服务重启后的持久化。

还把压缩包解压到干净目录，在不安装任何 npm 依赖的情况下重复通过上述检查。

Docker 配置已提供，但本次环境没有 Docker，未实机运行 Docker 构建；未在你的实际托管平台或中国内地网络验收。公网可达性、HTTPS、持久化磁盘和天气外部接口需要上线后确认。
