@echo off
cd /d "%~dp0"
if exist .env (node --env-file=.env server/index.mjs) else (node server/index.mjs)
pause
