import {build} from 'vite';
import ts from 'typescript';
import {readFile,writeFile} from 'node:fs/promises';
await build();
await writeFile('server/data.mjs',ts.transpileModule(await readFile('server/data.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
console.log('Frontend and backend built.');
