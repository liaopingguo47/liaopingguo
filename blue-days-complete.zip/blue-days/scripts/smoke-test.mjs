import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer} from 'node:net';
const probe=createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
const dir=await mkdtemp(join(tmpdir(),'blue-days-test-'));const base='http://127.0.0.1:'+port;
let child;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function start(){child=spawn(process.execPath,['server/index.mjs'],{cwd:process.cwd(),env:{...process.env,PORT:String(port),HOST:'127.0.0.1',DATA_DIR:dir,ADMIN_KEY:'test-admin-password',COOKIE_SECRET:'test-signing-key',PUBLIC_ORIGIN:base},stdio:'ignore'});for(let i=0;i<100;i++){try{if((await fetch(base+'/health')).ok)return;}catch{}await sleep(100);}throw Error('Server did not start');}
async function stop(){if(!child||child.exitCode!==null)return;await new Promise(r=>{child.once('exit',r);child.kill('SIGTERM');});}
const clients={};
async function request(name,path,body,extra={}){const headers={...extra};if(clients[name])headers.Cookie=clients[name];if(body){headers['Content-Type']='application/json';headers.Origin=base;}const r=await fetch(base+path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});const cookie=r.headers.get('set-cookie');if(cookie)clients[name]=cookie.split(';')[0];return {status:r.status,body:await r.json()};}
try{await start();const html=await fetch(base+'/');assert.equal(html.status,200);const markup=await html.text();const assets=[...markup.matchAll(/(?:src|href)="(\/assets\/[^\"]+)"/g)].map(m=>m[1]);assert.ok(assets.length>=2);for(const asset of assets)assert.equal((await fetch(base+asset)).status,200);assert.equal((await fetch(base+'/server/runtime.mjs')).status,404);
let a=await request('a','/api/data');assert.equal(a.body.points,1);assert.equal(a.body.plans.length,0);const date=a.body.today;let p=await request('a','/api/data',{action:'plan',date,play:['看电影','自己添加的活动'],food:['火锅'],note:'测试见面地点'});assert.equal(p.status,200);a=await request('a','/api/data');assert.equal(a.body.points,2);assert.equal(a.body.plans.length,1);
await request('a','/api/data',{action:'plan',date,play:['公园散步'],food:['浙菜'],note:'修改后'});a=await request('a','/api/data');assert.equal(a.body.points,2);assert.equal(JSON.parse(a.body.plans[0].play)[0],'公园散步');
let b=await request('b','/api/data');assert.equal(b.body.plans.length,1);assert.equal(b.body.points,1);
const wish={action:'wish',id:'smoke-wish-001',wish:'一本书',address:'测试地址，不是真实数据'};assert.equal((await request('a','/api/data',wish)).status,200);assert.equal((await request('a','/api/data',wish)).status,200);a=await request('a','/api/data');assert.equal(a.body.points,1);assert.equal(a.body.wishes.length,1);assert.equal((await request('b','/api/data')).body.wishes.length,0);
assert.equal((await request('a','/api/data',undefined,{'x-admin-key':'wrong'})).status,403);const admin=await request('a','/api/data',undefined,{'x-admin-key':'test-admin-password'});assert.equal(admin.body.wishes.length,1);
assert.equal((await request('a','/api/data',{action:'status',id:wish.id,status:'已完成'},{'x-admin-key':'test-admin-password'})).status,200);
assert.equal((await request('a','/api/data',{...wish,id:'smoke-wish-002'})).status,200);assert.equal((await request('a','/api/data',{...wish,id:'smoke-wish-003'})).status,400);
const bad=await fetch(base+'/api/data',{method:'POST',headers:{Cookie:clients.a,'Content-Type':'application/json',Origin:'https://other.example'},body:JSON.stringify({action:'plan',date,play:['x'],food:[],note:''})});assert.equal(bad.status,403);
const parallel=await Promise.all([request('b','/api/data',{...wish,id:'parallel-wish-01'}),request('b','/api/data',{...wish,id:'parallel-wish-02'})]);assert.deepEqual(parallel.map(r=>r.status).sort(),[200,400]);
await stop();await start();a=await request('a','/api/data');assert.equal(a.body.points,0);assert.equal(a.body.plans[0].note,'修改后');assert.equal(a.body.wishes.length,2);assert.equal(a.body.wishes.find(w=>w.id===wish.id).status,'已完成');
console.log('PASS: assets, shared plans, custom tags, updates, daily points, idempotent rewards/redemption, atomic balance, admin authorization/status, wish privacy, origin checks, and persistence after restart.');
}finally{await stop();await rm(dir,{recursive:true,force:true});}
